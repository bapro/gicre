
	<ul class="dropdown-menu">
		<li class="data-li"><a class="dropdown-item">FORMATO VERTICAL</a></li>
		<li class="data-li"><a  class="imprimirRecetasForPat dropdown-item"  target="_blank" href="<?php echo base_url("print_page/print_indicaciones/$table/$date/$historial_id/$id_opertor/$centro_medico/vert/1")?>"  style="cursor:pointer;color:black" >con la foto</a></li>
		<li class="data-li"><a  class="imprimirRecetasForPat dropdown-item"  target="_blank" href="<?php echo base_url("print_page/print_indicaciones/$table/$date/$historial_id/$id_opertor/$centro_medico/vert/0")?>"  style="cursor:pointer;color:black"  >Sin la foto</a></li>
		
		
		<li class="data-li"><a class="dropdown-item">FORMATO HORIZONTAL</a></li>
	   <li class="data-li"> <a  class="imprimirRecetasForPat horiz dropdown-item" id='1' target="_blank" href="<?php echo base_url("print_page/print_indicaciones/$table/$date/$historial_id/$id_opertor/$centro_medico/horiz/1")?>"  style="cursor:pointer;color:black" >con la foto</a></li>
		<li class="data-li"><a  class="imprimirRecetasForPat horiz dropdown-item" id='0' target="_blank" href="<?php echo base_url("print_page/print_indicaciones/$table/$date/$historial_id/$id_opertor/$centro_medico/horiz/0")?>"  style="cursor:pointer;color:black"  >Sin la foto</a></li>
		
		</ul>
		